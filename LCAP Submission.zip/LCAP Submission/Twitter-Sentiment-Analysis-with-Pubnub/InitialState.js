// http://docs.initialstateeventsapi.apiary.io/#reference/event-buckets/buckets-json/send-events?console=1
export default (request) => { 
    const xhr = require('xhr');
    // Setup initialstate access key
    const accessKey = "Customized_Access_Key";
    const events = request.message.events;
    const bucketKey = request.message.bucketKey;
    const http_options = {
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "X-IS-AccessKey": accessKey,
            "X-IS-BucketKey": bucketKey,
            "Accept-Version": "0.0.4"
        },
        body: JSON.stringify(events)
    };
    const url = "https://groker.initialstate.com/api/events";
    return xhr.fetch(url, http_options).then((x) => {
        return request.ok();
    });
}